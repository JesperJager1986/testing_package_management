def testing2():
    print('from testing2')
