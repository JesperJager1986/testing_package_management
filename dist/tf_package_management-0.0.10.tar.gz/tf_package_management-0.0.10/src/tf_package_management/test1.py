def testing1():
    print('from testing1')
